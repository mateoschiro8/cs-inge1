#!/bin/bash
vmLiveTyping-Stack/squeak CuisUniversity-6350.image