#!/bin/bash
vm-jit/CuisVM.app CuisUniversity-6350.image