# Dynamic Cuis Libraries

[Presentation](DynamicCuisLibraries.pdf) given by Felipe at the [Smalltalks 2023](https://smalltalks2023.fast.org.ar) conference at Buenos Aires.

This is the [Video recording of the presentation](https://youtu.be/OLpI0y3mGHU?si=83hFGH0fujxoZy7k)
