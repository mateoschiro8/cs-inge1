#!/bin/bash
vmLiveTyping/squeak CuisUniversity-6350.image