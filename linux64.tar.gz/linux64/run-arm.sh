#!/bin/bash
vmLiveTyping-ARM/squeak CuisUniversity-6350.image