# Bootstrap: Creating Minimal Imaged from Scratch

[Presentation](Bootstrap.key.pdf) given by Juan at the [Smalltalks 2023](https://smalltalks2023.fast.org.ar) conference at Buenos Aires.

This is the [Video recording of the presentation](https://youtu.be/MfAclig5XyI?si=bfEIgNzHURiC2y4H)
