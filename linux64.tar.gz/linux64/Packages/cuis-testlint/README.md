# cuis-testlint
Test Smell detector for Cuis Smalltalk

## Dependencies
- [Regex](https://github.com/nmingotti/Cuis-Smalltalk-Regex)